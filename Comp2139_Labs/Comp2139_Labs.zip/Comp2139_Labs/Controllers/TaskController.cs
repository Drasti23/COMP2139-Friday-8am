﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Comp2139_Labs.Models;
using Comp2139_Labs;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Comp2139_Labs.Data;
using Microsoft.AspNetCore.Http.HttpResults;

namespace Comp2139_Labs.Controllers
{
    public class TaskController : Controller
    {
        private readonly ApplicationDbContext _context;

        public TaskController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]

        public IActionResult Index(int projectId)
        {
            return View();
        }

        [HttpGet]

        public IActionResult Details(int id)
        {
            return View();
        }

        [HttpGet]

        public IActionResult Create(int projectId)
        {
            return View();
        }

        [HttpGet]

        public IActionResult Edit(int id)
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]

        public IActionResult DeleteConfirmed(int ProjectTaskId)
        {
            var task = _context.ProjectTasks.Find(ProjectTaskId);
            if (task != null)
            {
                _context.ProjectTasks.Remove(task);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index), new { projectId = task.ProjectId });
               
            }
            return NotFound();
        }
        
        public async Task<IActionResult> Search(int? projectId, string searchString) 
        {
            var taskQuery = _context.ProjectTasks.AsQueryable();
            bool searchPerformed = !String.IsNullOrEmpty(searchString);
            if (projectId.HasValue)
            {
                taskQuery = taskQuery.Where(t => t.ProjectId == projectId);

            }

            if (searchPerformed)
            {
                taskQuery = taskQuery.Where(t => t.Title.Contains(searchString)
                                              || t.Description.Contains(searchString));
            }

            var tasks = await taskQuery.ToListAsync();

            ViewBag.ProjectId = projectId;
            ViewData["SearchPerformed"] = searchPerformed;
            ViewData["SearchString"] = searchString;
            return NotFound();

        }
    }
}

